
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="calendar.css">
</head>
<body>
    <div class="custom-calendar-wrap">
        <div class="custom-inner">
            <div class="custom-header clearfix">
                <nav>
                    <a href="#" class="custom-btn custom-prev"></a>
                    <a href="#" class="custom-btn custom-next"></a>
                </nav>
                <h2 id="custom-month" class="custom-month"><?=  date("F"); ?></h2>
                <h3 id="custom-year" class="custom-year"><?= date("Y") ?></h3>
                
            </div>
            <div id="calendar" class="fc-calendar-container">
                <div class="fc-calendar fc-five-rows">
                    <div class="fc-head">
                        <div>Sun</div>
                        <div>Mon</div>
                        <div>Tue</div>
                        <div>Wed</div>
                        <div>Thu</div>
                        <div>Fri</div>
                        <div>Sat</div>
                    </div>
                    <div class="fc-body">
                        <div class="fc-row">
                            <div><span class="fc-date"></span></div>
                            <div><span class="fc-date"></span></div>
                            <div><span class="fc-date"></span></div>
                            <div><span class="fc-date"></span></div>
                            <div><span class="fc-date"></span></div>
                            <div><span class="fc-date">1</span></div>
                            <div><span class="fc-date">2</span></div>
                        </div>
                        <div class="fc-row">
                          <!-- 3 - 9 -->
                            <?php for($i = 3; $i <= 9 ; $i++) : ?>
                            <div class="<?= date("j") == $i ? "fc-today":"" ?>"><span class="fc-date"><?= $i ?></span></div>
                            <?php endfor; ?>
                        </div>
                        <div class="fc-row">
                            <?php for($i = 10; $i <= 16 ; $i++) : ?>
                            <div class="<?= date("j") == $i ? "fc-today":"" ?>"><span class="fc-date"><?= $i ?></span></div>
                            <?php endfor; ?>
                            
                        </div>
                        <div class="fc-row">
                            <!-- 17  - 23 -->
                            <div><span class="fc-date">17</span></div>
                            <div><span class="fc-date">18</span></div>
                            <div><span class="fc-date">19</span></div>
                            <div><span class="fc-date">20</span></div>
                            <div><span class="fc-date">21</span></div>
                            <div><span class="fc-date">22</span></div>
                            <div><span class="fc-date">23</span></div>
                        </div>
                        <div class="fc-row">
                            <!-- 24 - 30 -->
                            
                            <div><span class="fc-date">24</span></div>
                            <div><span class="fc-date">25</span></div>
                            <div><span class="fc-date">26</span></div>
                            <div><span class="fc-date">27</span></div>
                            <div><span class="fc-date">28</span></div>
                            <div><span class="fc-date"></span></div>
                            <div><span class="fc-date"></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


</body>

</html>