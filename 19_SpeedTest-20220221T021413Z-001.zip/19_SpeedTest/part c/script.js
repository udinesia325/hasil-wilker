function draggable(el) {
  // TODO
  let currX = 0;
  let currY = 0;

  el.addEventListener("drag", function (e) {
    currY = e.clientY;
    currX = e.clientX;
    el.style.top = e.clientY + "px";
    el.style.left = e.clientX + "px";
    console.log(currY);
  });
  el.addEventListener("dragend", () => {
    el.style.top = currY + "px";
    el.style.left = currX + "px";
  });
}

draggable(document.getElementById("draggable"));
