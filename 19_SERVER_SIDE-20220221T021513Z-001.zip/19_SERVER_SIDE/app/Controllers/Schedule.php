<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\{ScheduleModel,LoginModel,PlaceModel};

class Schedule extends ResourceController
{
    public $schedule;
    public $place;
    public function __construct() {
        $this->schedule = new ScheduleModel();
        $this->place = new PlaceModel();
        $this->login = new LoginModel();
    }
    /**
     * Return an array of resource objects, themselves in array format
     *
     * @return mixed
     */
    public function index()
    {
        //
        $token = $this->request->getVar("token");
        if ($token != session()->get("token") || $token == null) {
            return $this->unauthorized();
        }
        
        return $this->respond($this->schedule->findAll());
    }

    /**
     * Return the properties of a resource object
     *
     * @return mixed
     */
    public function show($id = null)
    {
        //
    }
    public function unauthorized()
    {
        return $this->respond([
            "message" => "Unautaorized user"
        ], 401);
    }
    public function forAdmin()
    {
        $role = $this->login->db->table("login")->where("token", session()->get("token"))->get()->getResultArray();
        return $role[0]["role"] == 'admin';
    }
    /**
     * Return a new resource object, with default properties
     *
     * @return mixed
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters
     *
     * @return mixed
     */
    public function create()
    {
        //
    }

    /**
     * Return the editable properties of a resource object
     *
     * @return mixed
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties
     *
     * @return mixed
     */
    public function update($id = null)
    {
        //
    }

    /**
     * Delete the designated resource object from the model
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        //
    }
}
