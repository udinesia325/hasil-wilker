<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\LoginModel;

class LoginApi extends ResourceController
{
    public $login;
    public function __construct()
    {
        $this->login = new LoginModel();
    }
    /**
     * Return an array of resource objects, themselves in array format
     *
     * @return mixed
     */
    public function login()
    {
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        $data = $this->login->db->table('login')->where('username', $username)
            ->where('password', $password)
            ->get()->getResultArray();
        // $
        if (count($data) == 0) {
            $res = [
                "message" => "invalid login"
            ];
            return $this->respond($res, 401);
        }
        session()->set("id_user", $data[0]["id_user"]);
        session()->set("token", $data[0]["token"]);
        $this->login->update(session()->get("id_user"), ["status" => 'login']);
        return $this->respond([
            "token" => $data[0]["token"],
            "role" => $data[0]["role"]
        ], 200);
    }



    public function logout()
    {
        $token = $this->request->getVar("token");
        $sessionToken = session()->get("token");
        if ($token != $sessionToken || $token == null) {
            return $this->respond([
                "message" => "Unauthorized user",
                "status" => 401
            ]);
        }
        $id_user = session()->get("id_user");
        $this->login->update($id_user, ["status" => "logout"]);
        session()->destroy();
        return $this->respond(["message"=>"logout success"],200);
    }

    public function index()
    {
        //
        return $this->respond([
            "message" => $this->login->findAll()
        ], 201);
    }

    /**
     * Return the properties of a resource object
     *
     * @return mixed
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Return a new resource object, with default properties
     *
     * @return mixed
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters
     *
     * @return mixed
     */
    public function create()
    {
        //
    }

    /**
     * Return the editable properties of a resource object
     *
     * @return mixed
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties
     *
     * @return mixed
     */
    public function update($id = null)
    {
        //
    }

    /**
     * Delete the designated resource object from the model
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        //
    }
}
