<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\{PlaceModel, LoginModel};
use CodeIgniter\Debug\Toolbar\Collectors\History;

class Place extends ResourceController
{
    public $place;
    public $login;
    public function __construct()
    {
        $this->place = new PlaceModel();
        $this->login = new LoginModel();
    }
    /**
     * Return an array of resource objects, themselves in array format
     *
     * @return mixed
     */
    public function index($id = null)
    {
        //
        $token = $this->request->getVar("token");
        if ($token != session()->get("token") || $token == null) {
            return $this->unauthorized();
        }
        if ($id != null) {
            $data = $this->place->find($id);
            return $this->respond($data, 200);
        } else {
            $data = $this->place->findAll();
            return $this->respond($data, 200);
        }
    }

    /**
     * Return the properties of a resource object
     *
     * @return mixed
     */
    public function unauthorized()
    {
        return $this->respond([
            "message" => "Unautaorized user"
        ], 401);
    }

    /**
     * Create a new resource object, from "posted" parameters
     * only for admin
     * @return mixed
     */
    public function create()
    {
        //
        $token = $this->request->getVar("token");
        if ($token != session()->get("token") || $token == null) {
            return $this->unauthorized();
        }
        if ($this->forAdmin()) {
            // store data
            $form = $this->request->getVar();
            $file = $this->request->getFile("image");
            $form["image_path"] = $file->getSize() > 0 ? $file->getName() : "not set";

            $this->place->save($form);
            $file->move("");
            return $this->respond(["message" => "create success"], 200);
        } else {
            return $this->respond([
                "message" => " Data cannot be processed"
            ], 422);
        }
    }
    public function forAdmin()
    {
        $role = $this->login->db->table("login")->where("token", session()->get("token"))->get()->getResultArray();
        return $role[0]["role"] == 'admin';
    }


    /**
     * Add or update a model resource, from "posted" properties
     *
     * @return mixed
     */
    public function update($id = null)
    {
        //
        $token = $this->request->getVar("token");
        if ($token != session()->get("token") || $token == null) {
            return $this->unauthorized();
        }
        if ($this->forAdmin()) {
            // update data
            $oldData = $this->place->find($id)[0];
            $form = $this->request->getVar();
            $form["id"] = $id;
            //untuk file gambar
            $file = $this->request->getFile("image");
            if ($file->getName() != null) {
                if ($file->getName() != $oldData["image_path"]) {
                    $form['image_path'] = $file->getName();
                }
            }
            $this->place->update($id, $form);
        } else {
            return $this->respond([
                "message" => " Data cannot be updated"
            ], 400);
        }
    }

    /**
     * Delete the designated resource object from the model
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        //
        $token = $this->request->getVar("token");
        if ($token != session()->get("token") || $token == null) {
            return $this->unauthorized();
        }
        if ($this->forAdmin()) {
            // delete data

            $this->place->delete($id);
            return $this->respond(["message" => "delete success", "status" => 200], 200);
        } else {
            return $this->respond([
                "message" => " Data cannot be deleted"
            ], 422);
        }
    }
}
