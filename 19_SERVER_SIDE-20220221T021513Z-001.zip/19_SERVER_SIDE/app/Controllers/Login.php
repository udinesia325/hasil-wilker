<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\LoginModel;

class Login extends BaseController
{
    public $login;
    public function __construct()
    {
        $this->login = new LoginModel();
    }
    public function login()
    {
        //

        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        $data = $this->login->db->table('login')->where('username', $username)
            ->where('password', $password)
            ->get()->getResultArray();
        // $
        header("Content-Type:application/json");
        if(count($data) == 0){
            return $this->handleLoginFail();
        }
        $success = [
            "token"=>$data[0]["token"],
            "role"=>strtoupper($data[0]["role"])
        ];
        $this->login->update($data[0],["status"=>"login"]);

        session()->set("id_user",$data[0]["id_user"]);
        session()->set("token",$data[0]["token"]);
        echo json_encode($success);
    }
    public function handleLoginFail()
    {
        return  json_encode([
            "message"=>"invalid login"
        ]);
    }
    public function logout()
    {
        $token = $this->request->getVar("token");
        $sessionToken = session()->get("token");
        if($token != $sessionToken || $token == null){
           return json_encode([
                "message"=>"Unauthoerized user",
                "status"=>401
            ]);
        }
        $id_user = session()->get("id_user");
        $this->login->update($id_user,["status"=>"logout"]);
        return json_encode(["message"=>"logout success"]);
    }
}
