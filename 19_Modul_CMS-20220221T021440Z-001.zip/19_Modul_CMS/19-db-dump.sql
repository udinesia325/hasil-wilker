-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2022 at 04:40 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `modul_cms_db`
--
CREATE DATABASE IF NOT EXISTS `modul_cms_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `modul_cms_db`;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aiowps_events`
--

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aiowps_failed_logins`
--

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aiowps_global_meta`
--

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aiowps_login_activity`
--

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aiowps_login_lockdown`
--

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_aiowps_permanent_block`
--

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_cntctfrm_field`
--

CREATE TABLE `wp_cntctfrm_field` (
  `id` int(11) NOT NULL,
  `name` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wp_cntctfrm_field`
--

INSERT INTO `wp_cntctfrm_field` (`id`, `name`) VALUES
(1, 'name'),
(2, 'email'),
(3, 'subject'),
(4, 'message'),
(5, 'gdpr'),
(6, 'address'),
(7, 'phone'),
(8, 'attachment'),
(9, 'attachment_explanations'),
(10, 'send_copy'),
(11, 'sent_from'),
(12, 'date_time'),
(13, 'coming_from'),
(14, 'user_agent');

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2022-02-07 00:55:53', '2022-02-07 00:55:53', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wordpress', 'yes'),
(2, 'home', 'http://localhost/wordpress', 'yes'),
(3, 'blogname', 'COVID-19 NEWS', 'yes'),
(4, 'blogdescription', 'Situs web news covid 19', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin20@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:120:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:10:\"vslides/?$\";s:27:\"index.php?post_type=vslides\";s:40:\"vslides/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=vslides&feed=$matches[1]\";s:35:\"vslides/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=vslides&feed=$matches[1]\";s:27:\"vslides/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=vslides&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:56:\"multiple_slider/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?multiple_slider=$matches[1]&feed=$matches[2]\";s:51:\"multiple_slider/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?multiple_slider=$matches[1]&feed=$matches[2]\";s:32:\"multiple_slider/([^/]+)/embed/?$\";s:48:\"index.php?multiple_slider=$matches[1]&embed=true\";s:44:\"multiple_slider/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?multiple_slider=$matches[1]&paged=$matches[2]\";s:26:\"multiple_slider/([^/]+)/?$\";s:37:\"index.php?multiple_slider=$matches[1]\";s:35:\"vslides/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"vslides/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"vslides/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"vslides/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"vslides/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"vslides/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"vslides/([^/]+)/embed/?$\";s:40:\"index.php?vslides=$matches[1]&embed=true\";s:28:\"vslides/([^/]+)/trackback/?$\";s:34:\"index.php?vslides=$matches[1]&tb=1\";s:48:\"vslides/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?vslides=$matches[1]&feed=$matches[2]\";s:43:\"vslides/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?vslides=$matches[1]&feed=$matches[2]\";s:36:\"vslides/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?vslides=$matches[1]&paged=$matches[2]\";s:43:\"vslides/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?vslides=$matches[1]&cpage=$matches[2]\";s:32:\"vslides/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?vslides=$matches[1]&page=$matches[2]\";s:24:\"vslides/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"vslides/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"vslides/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"vslides/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"vslides/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"vslides/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:36:\"contact-form-plugin/contact_form.php\";i:2;s:30:\"seo-by-rank-math/rank-math.php\";i:3;s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '7', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:4:{i:0;s:67:\"C:\\xampp\\htdocs\\wordpress/wp-content/themes/twentyfifteen/style.css\";i:2;s:71:\"C:\\xampp\\htdocs\\wordpress/wp-content/themes/twentyfifteen/functions.php\";i:3;s:67:\"C:\\xampp\\htdocs\\wordpress/wp-content/themes/twentysixteen/style.css\";i:4;s:0:\"\";}', 'no'),
(40, 'template', 'twentyfifteen', 'yes'),
(41, 'stylesheet', 'twentyfifteen', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:10:\"categories\";s:5:\"count\";i:1;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:2:{s:36:\"contact-form-plugin/contact_form.php\";s:23:\"cntctfrm_delete_options\";s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";s:21:\"wrjs_uninstall_slider\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:77:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:23:\"rank_math_edit_htaccess\";b:1;s:16:\"rank_math_titles\";b:1;s:17:\"rank_math_general\";b:1;s:17:\"rank_math_sitemap\";b:1;s:21:\"rank_math_404_monitor\";b:1;s:22:\"rank_math_link_builder\";b:1;s:22:\"rank_math_redirections\";b:1;s:22:\"rank_math_role_manager\";b:1;s:24:\"rank_math_search_console\";b:1;s:23:\"rank_math_site_analysis\";b:1;s:25:\"rank_math_onpage_analysis\";b:1;s:24:\"rank_math_onpage_general\";b:1;s:25:\"rank_math_onpage_advanced\";b:1;s:24:\"rank_math_onpage_snippet\";b:1;s:23:\"rank_math_onpage_social\";b:1;s:19:\"rank_math_admin_bar\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:39:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:23:\"rank_math_site_analysis\";b:1;s:25:\"rank_math_onpage_analysis\";b:1;s:24:\"rank_math_onpage_general\";b:1;s:24:\"rank_math_onpage_snippet\";b:1;s:23:\"rank_math_onpage_social\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:14:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:25:\"rank_math_onpage_analysis\";b:1;s:24:\"rank_math_onpage_general\";b:1;s:24:\"rank_math_onpage_snippet\";b:1;s:23:\"rank_math_onpage_social\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:3:{i:2;a:1:{s:5:\"title\";s:0:\"\";}i:3;a:1:{s:5:\"title\";s:6:\"Search\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:12:\"categories-2\";i:1;s:13:\"media_image-2\";i:2;s:8:\"search-3\";i:3;s:7:\"pages-2\";i:4;s:13:\"custom_html-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:2:{i:2;a:3:{s:5:\"title\";s:5:\"Pages\";s:6:\"sortby\";s:10:\"menu_order\";s:7:\"exclude\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:2:{i:2;a:15:{s:13:\"attachment_id\";i:0;s:3:\"url\";s:0:\"\";s:5:\"title\";s:6:\"gambar\";s:4:\"size\";s:6:\"medium\";s:5:\"width\";i:0;s:6:\"height\";i:0;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:2:{i:2;a:2:{s:5:\"title\";s:12:\"Follow Us On\";s:7:\"content\";s:111:\"<p>\r\n	<a href=\"www.facebook.com\">facebook</a>\r\n</p>\r\n<p>\r\n	<a>Instagram</a>\r\n</p>\r\n<p>\r\n	<a>twitter</a>\r\n</p>\r\n\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:14:{i:1644206155;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1644206350;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1644206457;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"455b166fb23809d3accb82d7b0003ccd\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:38;}}}}i:1644206498;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"b4267a67df0cfb11e30d6396f858b5c9\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:40;}}}}i:1644206537;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"2f39f82b6c5c6c7599fc22a165eada38\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:41;}}}}i:1644206562;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"9faa5555021560fb2a78d8c9f3513bc5\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:42;}}}}i:1644207230;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"90769b99ac5e069f750a77f27934e890\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:43;}}}}i:1644209934;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"c7c97442c7bbde2137452591b932e68d\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:49;}}}}i:1644238555;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1644278400;a:4:{s:28:\"rank_math/tracker/send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:38:\"rank_math/search_console/get_analytics\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:35:\"rank_math/redirection/clean_trashed\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"rank_math/links/internal_links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1644281770;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1644281956;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1644289150;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:3:\"top\";i:2;s:6:\"social\";i:0;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1644196290;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(116, '_site_transient_update_core', 'O:8:\"stdClass\":3:{s:7:\"updates\";a:0:{}s:15:\"version_checked\";s:5:\"4.9.9\";s:12:\"last_checked\";i:1644202739;}', 'no'),
(120, '_site_transient_update_themes', 'O:8:\"stdClass\":1:{s:12:\"last_checked\";i:1644202868;}', 'no'),
(122, 'can_compress_scripts', '1', 'no'),
(123, '_transient_timeout_plugin_slugs', '1644291468', 'no'),
(124, '_transient_plugin_slugs', 'a:9:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:36:\"contact-form-plugin/contact_form.php\";i:4;s:9:\"hello.php\";i:5;s:30:\"seo-by-rank-math/rank-math.php\";i:6;s:35:\"autodescription/autodescription.php\";i:7;s:46:\"wonderplugin-carousel/wonderplugincarousel.php\";i:8;s:59:\"wp-responsive-jquery-slider/wp-responsive-jquery-slider.php\";}', 'no'),
(125, 'recently_activated', 'a:0:{}', 'yes'),
(126, '_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b', '1644238582', 'no'),
(127, '_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b', '<div class=\"rss-widget\"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: wordpress.org</p></div><div class=\"rss-widget\"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 28: Connection timed out after 10001 milliseconds</p></div>', 'no'),
(131, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(151, '_transient_twentyseventeen_categories', '1', 'yes'),
(152, 'theme_mods_twentysixteen', 'a:5:{s:18:\"custom_css_post_id\";i:20;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:6:\"social\";i:0;}s:21:\"page_background_color\";s:7:\"#bbe9ea\";s:10:\"link_color\";s:7:\"#000000\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1644198003;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:1:{i:0;s:12:\"categories-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(154, 'theme_switch_menu_locations', 'a:2:{s:7:\"primary\";i:2;s:6:\"social\";i:0;}', 'yes'),
(155, 'current_theme', 'Twenty Fifteen', 'yes'),
(156, 'theme_switched', '', 'yes'),
(157, 'theme_switched_via_customizer', '', 'yes'),
(158, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(199, '_transient_twentysixteen_categories', '1', 'yes'),
(200, 'theme_mods_twentyfifteen', 'a:5:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:6:\"social\";i:0;}s:17:\"sidebar_textcolor\";s:7:\"#ffffff\";s:23:\"header_background_color\";s:7:\"#32c1a9\";s:16:\"background_color\";s:6:\"056662\";}', 'yes'),
(209, 'WPLANG', '', 'yes'),
(210, 'new_admin_email', 'admin20@gmail.com', 'yes'),
(214, 'cntctfrm_options', 'a:70:{s:21:\"plugin_option_version\";s:5:\"4.1.5\";s:23:\"display_settings_notice\";i:1;s:13:\"first_install\";i:1644198495;s:22:\"suggest_feature_banner\";i:1;s:10:\"user_email\";s:5:\"admin\";s:12:\"custom_email\";s:17:\"admin20@gmail.com\";s:12:\"select_email\";s:6:\"custom\";s:10:\"from_email\";s:6:\"custom\";s:17:\"custom_from_email\";s:19:\"wordpress@localhost\";s:10:\"attachment\";i:0;s:23:\"attachment_explanations\";i:1;s:9:\"send_copy\";i:0;s:4:\"gdpr\";i:0;s:10:\"from_field\";s:13:\"COVID-19 NEWS\";s:17:\"select_from_field\";s:6:\"custom\";s:18:\"display_name_field\";i:1;s:21:\"display_address_field\";i:0;s:19:\"display_phone_field\";i:0;s:19:\"required_name_field\";i:1;s:22:\"required_address_field\";i:0;s:20:\"required_email_field\";i:1;s:20:\"required_phone_field\";i:0;s:22:\"required_subject_field\";i:1;s:22:\"required_message_field\";i:1;s:15:\"required_symbol\";s:1:\"*\";s:16:\"display_add_info\";i:1;s:17:\"display_sent_from\";i:1;s:17:\"display_date_time\";i:1;s:11:\"mail_method\";s:7:\"wp-mail\";s:19:\"display_coming_from\";i:1;s:18:\"display_user_agent\";i:1;s:8:\"language\";a:0:{}s:12:\"change_label\";i:0;s:9:\"gdpr_link\";s:0:\"\";s:10:\"name_label\";a:1:{s:7:\"default\";s:5:\"Name:\";}s:13:\"address_label\";a:1:{s:7:\"default\";s:8:\"Address:\";}s:11:\"email_label\";a:1:{s:7:\"default\";s:14:\"Email Address:\";}s:11:\"phone_label\";a:1:{s:7:\"default\";s:13:\"Phone number:\";}s:13:\"subject_label\";a:1:{s:7:\"default\";s:8:\"Subject:\";}s:13:\"message_label\";a:1:{s:7:\"default\";s:8:\"Message:\";}s:16:\"attachment_label\";a:1:{s:7:\"default\";s:11:\"Attachment:\";}s:18:\"attachment_tooltip\";a:1:{s:7:\"default\";s:144:\"Supported file types: HTML, TXT, CSS, GIF, PNG, JPEG, JPG, TIFF, BMP, AI, EPS, PS, CSV, RTF, PDF, DOC, DOCX, XLS, XLSX, ZIP, RAR, WAV, MP3, PPT.\";}s:15:\"send_copy_label\";a:1:{s:7:\"default\";s:14:\"Send me a copy\";}s:10:\"gdpr_label\";a:1:{s:7:\"default\";s:55:\"I consent to having this site collect my personal data.\";}s:16:\"gdpr_text_button\";a:1:{s:7:\"default\";s:10:\"Learn more\";}s:12:\"submit_label\";a:1:{s:7:\"default\";s:6:\"Submit\";}s:10:\"name_error\";a:1:{s:7:\"default\";s:22:\"Your name is required.\";}s:13:\"address_error\";a:1:{s:7:\"default\";s:20:\"Address is required.\";}s:11:\"email_error\";a:1:{s:7:\"default\";s:34:\"A valid email address is required.\";}s:11:\"phone_error\";a:1:{s:7:\"default\";s:25:\"Phone number is required.\";}s:13:\"subject_error\";a:1:{s:7:\"default\";s:20:\"Subject is required.\";}s:13:\"message_error\";a:1:{s:7:\"default\";s:25:\"Message text is required.\";}s:16:\"attachment_error\";a:1:{s:7:\"default\";s:25:\"File format is not valid.\";}s:23:\"attachment_upload_error\";a:1:{s:7:\"default\";s:18:\"File upload error.\";}s:21:\"attachment_move_error\";a:1:{s:7:\"default\";s:31:\"The file could not be uploaded.\";}s:21:\"attachment_size_error\";a:1:{s:7:\"default\";s:23:\"This file is too large.\";}s:13:\"captcha_error\";a:1:{s:7:\"default\";s:28:\"Please fill out the CAPTCHA.\";}s:10:\"form_error\";a:1:{s:7:\"default\";s:44:\"Please make corrections below and try again.\";}s:17:\"action_after_send\";i:1;s:10:\"thank_text\";a:1:{s:7:\"default\";s:28:\"Thank you for contacting us.\";}s:12:\"redirect_url\";s:0:\"\";s:20:\"delete_attached_file\";s:1:\"0\";s:10:\"html_email\";i:1;s:21:\"change_label_in_email\";i:0;s:6:\"layout\";i:1;s:15:\"submit_position\";s:4:\"left\";s:12:\"order_fields\";a:2:{s:12:\"first_column\";a:11:{i:0;s:21:\"cntctfrm_contact_name\";i:1;s:24:\"cntctfrm_contact_address\";i:2;s:22:\"cntctfrm_contact_email\";i:3;s:22:\"cntctfrm_contact_phone\";i:4;s:24:\"cntctfrm_contact_subject\";i:5;s:24:\"cntctfrm_contact_message\";i:6;s:21:\"cntctfrm_contact_gdpr\";i:7;s:27:\"cntctfrm_contact_attachment\";i:8;s:26:\"cntctfrm_contact_send_copy\";i:9;s:18:\"cntctfrm_subscribe\";i:10;s:16:\"cntctfrm_captcha\";}s:13:\"second_column\";a:0:{}}s:5:\"width\";a:3:{s:4:\"type\";s:7:\"default\";s:11:\"input_value\";s:3:\"100\";s:10:\"input_unit\";s:1:\"%\";}s:23:\"active_multi_attachment\";i:0;s:17:\"plugin_db_version\";s:5:\"4.1.1\";}', 'yes'),
(215, 'bstwbsftwppdtplgns_options', 'a:1:{s:8:\"bws_menu\";a:1:{s:7:\"version\";a:1:{s:36:\"contact-form-plugin/contact_form.php\";s:5:\"2.1.7\";}}}', 'yes'),
(217, 'category_children', 'a:1:{i:1;a:2:{i:0;i:5;i:1;i:7;}}', 'yes'),
(230, 'get_settings_option', 'a:11:{s:10:\"width_wrjs\";s:3:\"960\";s:12:\"caption_wrjs\";s:3:\"yes\";s:11:\"height_wrjs\";s:3:\"350\";s:11:\"effect_wrjs\";s:5:\"slide\";s:14:\"direction_wrjs\";s:8:\"vertical\";s:9:\"post_wrjs\";s:6:\"vslide\";s:10:\"delay_wrjs\";s:4:\"5000\";s:13:\"duration_wrjs\";s:3:\"600\";s:19:\"show_panel_nav_wrjs\";s:1:\"1\";s:10:\"start_wrjs\";i:1;s:17:\"pauseOnHover_wrjs\";s:1:\"1\";}', 'yes'),
(233, 'rank_math_search_console_data', 'a:2:{s:10:\"authorized\";b:0;s:8:\"profiles\";a:0:{}}', 'yes'),
(234, 'rank_math_known_post_types', 'a:4:{s:4:\"post\";s:4:\"post\";s:4:\"page\";s:4:\"page\";s:10:\"attachment\";s:10:\"attachment\";s:7:\"vslides\";s:7:\"vslides\";}', 'yes'),
(235, 'rank_math_modules', 'a:9:{i:0;s:12:\"link-counter\";i:1;s:14:\"search-console\";i:2;s:12:\"seo-analysis\";i:3;s:7:\"sitemap\";i:4;s:12:\"rich-snippet\";i:5;s:11:\"woocommerce\";i:6;s:12:\"role-manager\";i:7;s:9:\"local-seo\";i:8;s:11:\"404-monitor\";}', 'yes'),
(236, 'rank-math-options-general', 'a:36:{s:19:\"strip_category_base\";s:3:\"off\";s:24:\"attachment_redirect_urls\";s:2:\"on\";s:27:\"attachment_redirect_default\";s:26:\"http://localhost/wordpress\";s:19:\"url_strip_stopwords\";s:3:\"off\";s:23:\"nofollow_external_links\";s:3:\"off\";s:20:\"nofollow_image_links\";s:2:\"on\";s:25:\"new_window_external_links\";s:2:\"on\";s:11:\"add_img_alt\";s:3:\"off\";s:14:\"img_alt_format\";s:20:\"%title% %count(alt)%\";s:13:\"add_img_title\";s:3:\"off\";s:16:\"img_title_format\";s:22:\"%title% %count(title)%\";s:11:\"breadcrumbs\";s:3:\"off\";s:21:\"breadcrumbs_separator\";s:1:\"-\";s:16:\"breadcrumbs_home\";s:2:\"on\";s:22:\"breadcrumbs_home_label\";s:4:\"Home\";s:26:\"breadcrumbs_archive_format\";s:15:\"Archives for %s\";s:25:\"breadcrumbs_search_format\";s:14:\"Results for %s\";s:21:\"breadcrumbs_404_label\";s:25:\"404 Error: page not found\";s:31:\"breadcrumbs_ancestor_categories\";s:3:\"off\";s:16:\"404_monitor_mode\";s:6:\"simple\";s:17:\"404_monitor_limit\";i:100;s:35:\"404_monitor_ignore_query_parameters\";s:2:\"on\";s:24:\"redirections_header_code\";s:3:\"301\";s:18:\"redirections_debug\";s:3:\"off\";s:15:\"console_profile\";s:0:\"\";s:23:\"console_caching_control\";s:2:\"90\";s:27:\"link_builder_links_per_page\";s:1:\"7\";s:29:\"link_builder_links_per_target\";s:1:\"1\";s:22:\"wc_remove_product_base\";s:3:\"off\";s:23:\"wc_remove_category_base\";s:3:\"off\";s:31:\"wc_remove_category_parent_slugs\";s:3:\"off\";s:18:\"rss_before_content\";s:0:\"\";s:17:\"rss_after_content\";s:0:\"\";s:14:\"usage_tracking\";s:2:\"on\";s:19:\"wc_remove_generator\";s:2:\"on\";s:24:\"remove_shop_snippet_data\";s:2:\"on\";}', 'yes'),
(237, 'rank-math-options-titles', 'a:103:{s:24:\"noindex_empty_taxonomies\";s:2:\"on\";s:15:\"title_separator\";s:1:\"-\";s:17:\"capitalize_titles\";s:3:\"off\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:19:\"knowledgegraph_type\";s:7:\"company\";s:19:\"knowledgegraph_name\";s:13:\"COVID-19 NEWS\";s:19:\"local_business_type\";s:23:\"HealthAndBeautyBusiness\";s:20:\"local_address_format\";s:43:\"{address} {locality}, {region} {postalcode}\";s:13:\"opening_hours\";a:7:{i:0;a:2:{s:3:\"day\";s:6:\"Monday\";s:4:\"time\";s:11:\"09:00-17:00\";}i:1;a:2:{s:3:\"day\";s:7:\"Tuesday\";s:4:\"time\";s:11:\"09:00-17:00\";}i:2;a:2:{s:3:\"day\";s:9:\"Wednesday\";s:4:\"time\";s:11:\"09:00-17:00\";}i:3;a:2:{s:3:\"day\";s:8:\"Thursday\";s:4:\"time\";s:11:\"09:00-17:00\";}i:4;a:2:{s:3:\"day\";s:6:\"Friday\";s:4:\"time\";s:11:\"09:00-17:00\";}i:5;a:2:{s:3:\"day\";s:8:\"Saturday\";s:4:\"time\";s:11:\"09:00-17:00\";}i:6;a:2:{s:3:\"day\";s:6:\"Sunday\";s:4:\"time\";s:11:\"09:00-17:00\";}}s:20:\"opening_hours_format\";s:3:\"off\";s:14:\"homepage_title\";s:34:\"%sitename% %page% %sep% %sitedesc%\";s:20:\"homepage_description\";s:0:\"\";s:22:\"homepage_custom_robots\";s:3:\"off\";s:23:\"disable_author_archives\";s:3:\"off\";s:15:\"url_author_base\";s:6:\"author\";s:20:\"author_custom_robots\";s:2:\"on\";s:13:\"author_robots\";a:1:{i:0;s:7:\"noindex\";}s:20:\"author_archive_title\";s:30:\"%name% %sep% %sitename% %page%\";s:19:\"author_add_meta_box\";s:2:\"on\";s:21:\"disable_date_archives\";s:3:\"off\";s:18:\"date_archive_title\";s:30:\"%date% %page% %sep% %sitename%\";s:12:\"search_title\";s:38:\"%search_query% %page% %sep% %sitename%\";s:9:\"404_title\";s:31:\"Page Not Found %sep% %sitename%\";s:19:\"date_archive_robots\";a:1:{i:0;s:7:\"noindex\";}s:14:\"noindex_search\";s:2:\"on\";s:24:\"noindex_archive_subpages\";s:3:\"off\";s:26:\"noindex_password_protected\";s:3:\"off\";s:13:\"pt_post_title\";s:24:\"%title% %sep% %sitename%\";s:19:\"pt_post_description\";s:9:\"%excerpt%\";s:14:\"pt_post_robots\";a:0:{}s:21:\"pt_post_custom_robots\";s:3:\"off\";s:28:\"pt_post_default_rich_snippet\";s:7:\"article\";s:28:\"pt_post_default_article_type\";s:11:\"BlogPosting\";s:28:\"pt_post_default_snippet_name\";s:7:\"%title%\";s:28:\"pt_post_default_snippet_desc\";s:9:\"%excerpt%\";s:17:\"pt_post_ls_use_fk\";s:6:\"titles\";s:20:\"pt_post_add_meta_box\";s:2:\"on\";s:20:\"pt_post_bulk_editing\";s:7:\"editing\";s:24:\"pt_post_link_suggestions\";s:2:\"on\";s:24:\"pt_post_primary_taxonomy\";s:8:\"category\";s:13:\"pt_page_title\";s:24:\"%title% %sep% %sitename%\";s:19:\"pt_page_description\";s:9:\"%excerpt%\";s:14:\"pt_page_robots\";a:0:{}s:21:\"pt_page_custom_robots\";s:3:\"off\";s:28:\"pt_page_default_rich_snippet\";s:7:\"article\";s:28:\"pt_page_default_article_type\";s:7:\"Article\";s:28:\"pt_page_default_snippet_name\";s:7:\"%title%\";s:28:\"pt_page_default_snippet_desc\";s:9:\"%excerpt%\";s:17:\"pt_page_ls_use_fk\";s:6:\"titles\";s:20:\"pt_page_add_meta_box\";s:2:\"on\";s:20:\"pt_page_bulk_editing\";s:7:\"editing\";s:24:\"pt_page_link_suggestions\";s:2:\"on\";s:19:\"pt_attachment_title\";s:24:\"%title% %sep% %sitename%\";s:25:\"pt_attachment_description\";s:9:\"%excerpt%\";s:20:\"pt_attachment_robots\";a:1:{i:0;s:7:\"noindex\";}s:27:\"pt_attachment_custom_robots\";s:2:\"on\";s:34:\"pt_attachment_default_rich_snippet\";s:3:\"off\";s:34:\"pt_attachment_default_article_type\";s:7:\"Article\";s:34:\"pt_attachment_default_snippet_name\";s:7:\"%title%\";s:34:\"pt_attachment_default_snippet_desc\";s:9:\"%excerpt%\";s:26:\"pt_attachment_add_meta_box\";s:3:\"off\";s:16:\"pt_vslides_title\";s:24:\"%title% %sep% %sitename%\";s:22:\"pt_vslides_description\";s:9:\"%excerpt%\";s:17:\"pt_vslides_robots\";a:0:{}s:24:\"pt_vslides_custom_robots\";s:3:\"off\";s:31:\"pt_vslides_default_rich_snippet\";s:3:\"off\";s:31:\"pt_vslides_default_article_type\";s:7:\"Article\";s:31:\"pt_vslides_default_snippet_name\";s:7:\"%title%\";s:31:\"pt_vslides_default_snippet_desc\";s:9:\"%excerpt%\";s:24:\"pt_vslides_archive_title\";s:31:\"%title% %page% %sep% %sitename%\";s:20:\"pt_vslides_ls_use_fk\";s:6:\"titles\";s:23:\"pt_vslides_add_meta_box\";s:2:\"on\";s:23:\"pt_vslides_bulk_editing\";s:7:\"editing\";s:27:\"pt_vslides_link_suggestions\";s:2:\"on\";s:16:\"pt_product_title\";s:24:\"%title% %sep% %sitename%\";s:22:\"pt_product_description\";s:9:\"%excerpt%\";s:17:\"pt_product_robots\";a:0:{}s:24:\"pt_product_custom_robots\";s:3:\"off\";s:31:\"pt_product_default_rich_snippet\";s:7:\"product\";s:31:\"pt_product_default_article_type\";s:7:\"Article\";s:31:\"pt_product_default_snippet_name\";s:7:\"%title%\";s:31:\"pt_product_default_snippet_desc\";s:9:\"%excerpt%\";s:20:\"pt_product_ls_use_fk\";s:6:\"titles\";s:23:\"pt_product_add_meta_box\";s:2:\"on\";s:23:\"pt_product_bulk_editing\";s:7:\"editing\";s:27:\"pt_product_link_suggestions\";s:2:\"on\";s:27:\"pt_product_primary_taxonomy\";s:11:\"product_cat\";s:18:\"tax_category_title\";s:23:\"%term% %sep% %sitename%\";s:19:\"tax_category_robots\";a:0:{}s:25:\"tax_category_add_meta_box\";s:2:\"on\";s:26:\"tax_category_custom_robots\";s:3:\"off\";s:18:\"tax_post_tag_title\";s:23:\"%term% %sep% %sitename%\";s:19:\"tax_post_tag_robots\";a:1:{i:0;s:7:\"noindex\";}s:25:\"tax_post_tag_add_meta_box\";s:2:\"on\";s:26:\"tax_post_tag_custom_robots\";s:2:\"on\";s:21:\"tax_post_format_title\";s:23:\"%term% %sep% %sitename%\";s:22:\"tax_post_format_robots\";a:1:{i:0;s:7:\"noindex\";}s:28:\"tax_post_format_add_meta_box\";s:2:\"on\";s:29:\"tax_post_format_custom_robots\";s:2:\"on\";s:25:\"tax_multiple_slider_title\";s:23:\"%term% %sep% %sitename%\";s:26:\"tax_multiple_slider_robots\";a:0:{}s:32:\"tax_multiple_slider_add_meta_box\";s:2:\"on\";s:33:\"tax_multiple_slider_custom_robots\";s:3:\"off\";}', 'yes'),
(238, 'rank-math-options-sitemap', 'a:14:{s:14:\"items_per_page\";i:200;s:14:\"include_images\";s:2:\"on\";s:22:\"include_featured_image\";s:3:\"off\";s:19:\"ping_search_engines\";s:2:\"on\";s:13:\"exclude_roles\";a:2:{s:11:\"contributor\";s:11:\"Contributor\";s:10:\"subscriber\";s:10:\"Subscriber\";}s:15:\"pt_post_sitemap\";s:2:\"on\";s:15:\"pt_page_sitemap\";s:2:\"on\";s:21:\"pt_attachment_sitemap\";s:3:\"off\";s:18:\"pt_vslides_sitemap\";s:2:\"on\";s:18:\"pt_product_sitemap\";s:2:\"on\";s:20:\"tax_category_sitemap\";s:2:\"on\";s:20:\"tax_post_tag_sitemap\";s:3:\"off\";s:23:\"tax_post_format_sitemap\";s:3:\"off\";s:27:\"tax_multiple_slider_sitemap\";s:3:\"off\";}', 'yes'),
(241, 'rank_math_version', '1.0.24', 'yes'),
(242, 'rank_math_db_version', '1', 'yes'),
(243, 'rank_math_install_date', '1644224521', 'yes'),
(245, '_transient_rank_math_first_submenu_id', 'rank-math', 'yes'),
(277, '_site_transient_update_plugins', 'O:8:\"stdClass\":1:{s:12:\"last_checked\";i:1644205057;}', 'no'),
(278, 'aiowpsec_db_version', '1.9', 'yes'),
(279, 'aio_wp_security_configs', 'a:91:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:17:\"admin20@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"0u715f1a413gli4zskrw\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"4wigvf5520bmxictx1tt\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:17:\"admin20@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:17:\"admin20@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}', 'yes'),
(280, '_transient_timeout_users_online', '1644206362', 'no'),
(281, '_transient_users_online', 'a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1644229762;s:10:\"ip_address\";s:3:\"::1\";}}', 'no'),
(297, 'rank_math_registration_skip', '1', 'yes'),
(298, '_transient_timeout_rank_math_sc_is_empty', '1644290695', 'no'),
(299, '_transient_rank_math_sc_is_empty', '1', 'no'),
(300, '_transient_timeout_rank_math_sc_info', '1644290696', 'no'),
(301, '_transient_rank_math_sc_info', 'a:3:{s:4:\"days\";s:1:\"0\";s:4:\"rows\";s:1:\"0\";s:4:\"size\";s:5:\"32768\";}', 'no'),
(302, 'rank_math_wizard_completed', '1', 'yes'),
(303, '_transient__rank_math_site_type', 'news', 'yes'),
(305, 'rank_math_is_configured', '1', 'yes'),
(306, '_site_transient_timeout_theme_roots', '1644206526', 'no'),
(307, '_site_transient_theme_roots', 'a:3:{s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(308, '_transient_is_multi_author', '0', 'yes'),
(309, '_transient_twentyfifteen_categories', '1', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1644204035:1'),
(4, 5, '_edit_last', '1'),
(7, 7, '_edit_lock', '1644200584:1'),
(8, 7, '_edit_last', '1'),
(18, 10, '_edit_lock', '1644197970:1'),
(19, 10, '_edit_last', '1'),
(20, 12, '_wp_trash_meta_status', 'publish'),
(21, 12, '_wp_trash_meta_time', '1644195991'),
(28, 16, '_menu_item_type', 'custom'),
(29, 16, '_menu_item_menu_item_parent', '54'),
(30, 16, '_menu_item_object_id', '16'),
(31, 16, '_menu_item_object', 'custom'),
(32, 16, '_menu_item_target', ''),
(33, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(34, 16, '_menu_item_xfn', ''),
(35, 16, '_menu_item_url', 'http://localhost/wordpress/2022/02/07/news-update/'),
(37, 17, '_wp_trash_meta_status', 'publish'),
(38, 17, '_wp_trash_meta_time', '1644196290'),
(39, 18, '_menu_item_type', 'custom'),
(40, 18, '_menu_item_menu_item_parent', '0'),
(41, 18, '_menu_item_object_id', '18'),
(42, 18, '_menu_item_object', 'custom'),
(43, 18, '_menu_item_target', ''),
(44, 18, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(45, 18, '_menu_item_xfn', ''),
(46, 18, '_menu_item_url', 'http://localhost/wordpress'),
(48, 19, '_wp_trash_meta_status', 'publish'),
(49, 19, '_wp_trash_meta_time', '1644196803'),
(50, 22, '_edit_lock', '1644203845:1'),
(51, 22, '_edit_last', '1'),
(54, 24, '_menu_item_type', 'custom'),
(55, 24, '_menu_item_menu_item_parent', '54'),
(56, 24, '_menu_item_object_id', '24'),
(57, 24, '_menu_item_object', 'custom'),
(58, 24, '_menu_item_target', ''),
(59, 24, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(60, 24, '_menu_item_xfn', ''),
(61, 24, '_menu_item_url', 'http://localhost/wordpress/2022/02/07/covid-19-events/'),
(63, 25, '_wp_trash_meta_status', 'publish'),
(64, 25, '_wp_trash_meta_time', '1644197490'),
(65, 26, '_edit_lock', '1644197513:1'),
(66, 26, '_wp_trash_meta_status', 'publish'),
(67, 26, '_wp_trash_meta_time', '1644197535'),
(68, 27, '_edit_lock', '1644197594:1'),
(69, 27, '_wp_trash_meta_status', 'publish'),
(70, 27, '_wp_trash_meta_time', '1644197630'),
(71, 2, '_wp_trash_meta_status', 'publish'),
(72, 2, '_wp_trash_meta_time', '1644197717'),
(73, 2, '_wp_desired_post_slug', 'sample-page'),
(74, 29, '_wp_trash_meta_status', 'publish'),
(75, 29, '_wp_trash_meta_time', '1644197818'),
(76, 30, '_wp_trash_meta_status', 'publish'),
(77, 30, '_wp_trash_meta_time', '1644198003'),
(78, 31, '_edit_lock', '1644198031:1'),
(79, 31, '_wp_trash_meta_status', 'publish'),
(80, 31, '_wp_trash_meta_time', '1644198045'),
(81, 3, '_edit_lock', '1644197986:1'),
(82, 1, '_wp_trash_meta_status', 'publish'),
(83, 1, '_wp_trash_meta_time', '1644198211'),
(84, 1, '_wp_desired_post_slug', 'hello-world'),
(85, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(86, 33, '_edit_lock', '1644198177:1'),
(87, 33, '_edit_last', '1'),
(90, 33, '_wp_trash_meta_status', 'publish'),
(91, 33, '_wp_trash_meta_time', '1644198325'),
(92, 33, '_wp_desired_post_slug', 'social-media'),
(99, 39, '_wp_attached_file', '2022/02/seo-by-rank-math.1.0.24.zip'),
(100, 39, '_wp_attachment_context', 'upgrader'),
(107, 43, '_wp_attached_file', '2022/02/blankslate.2022-1.zip'),
(108, 43, '_wp_attachment_context', 'upgrader'),
(109, 45, '_edit_lock', '1644200114:2'),
(110, 45, '_edit_last', '2'),
(111, 45, '_slide_link_url', ''),
(112, 45, 'rank_math_title', 'covid news'),
(113, 45, 'rank_math_permalink', 'localhost/wordpress'),
(114, 45, 'rank_math_description', 'halaman web untuk melihat berita terkini tentang covid 19'),
(115, 45, 'rank_math_focus_keyword', 'news'),
(116, 45, 'rank_math_primary_multiple_slider', '0'),
(117, 45, 'rank_math_seo_score', '34'),
(118, 45, 'rank_math_facebook_enable_image_overlay', 'off'),
(119, 45, 'rank_math_facebook_image_overlay', 'play'),
(120, 45, 'rank_math_twitter_use_facebook', 'on'),
(121, 45, 'rank_math_twitter_card_type', 'summary_large_image'),
(122, 45, 'rank_math_twitter_enable_image_overlay', 'off'),
(123, 45, 'rank_math_twitter_image_overlay', 'play'),
(124, 7, '_wp_trash_meta_status', 'publish'),
(125, 7, '_wp_trash_meta_time', '1644200728'),
(126, 7, '_wp_desired_post_slug', 'categories'),
(129, 22, 'rank_math_permalink', 'covid-19-events'),
(130, 22, 'rank_math_primary_category', '0'),
(131, 22, 'rank_math_seo_score', '65'),
(132, 22, 'rank_math_robots', 'a:1:{i:0;s:5:\"index\";}'),
(133, 22, 'rank_math_facebook_enable_image_overlay', 'off'),
(134, 22, 'rank_math_facebook_image_overlay', 'play'),
(135, 22, 'rank_math_twitter_use_facebook', 'on'),
(136, 22, 'rank_math_twitter_card_type', 'summary_large_image'),
(137, 22, 'rank_math_twitter_enable_image_overlay', 'off'),
(138, 22, 'rank_math_twitter_image_overlay', 'play'),
(139, 46, '_edit_lock', '1644201791:1'),
(140, 46, '_wp_trash_meta_status', 'publish'),
(141, 46, '_wp_trash_meta_time', '1644201829'),
(142, 47, '_edit_lock', '1644202288:1'),
(143, 47, '_customize_restore_dismissed', '1'),
(149, 22, 'rank_math_focus_keyword', 'covid 19 events'),
(152, 5, 'rank_math_title', 'covid 19 news update'),
(153, 5, 'rank_math_permalink', 'news-update'),
(154, 5, 'rank_math_focus_keyword', 'news update'),
(155, 5, 'rank_math_primary_category', '0'),
(156, 5, 'rank_math_seo_score', '69'),
(157, 5, 'rank_math_robots', 'a:1:{i:0;s:5:\"index\";}'),
(158, 5, 'rank_math_facebook_enable_image_overlay', 'off'),
(159, 5, 'rank_math_facebook_image_overlay', 'play'),
(160, 5, 'rank_math_twitter_use_facebook', 'on'),
(161, 5, 'rank_math_twitter_card_type', 'summary_large_image'),
(162, 5, 'rank_math_twitter_enable_image_overlay', 'off'),
(163, 5, 'rank_math_twitter_image_overlay', 'play'),
(164, 54, '_menu_item_type', 'custom'),
(165, 54, '_menu_item_menu_item_parent', '0'),
(166, 54, '_menu_item_object_id', '54'),
(167, 54, '_menu_item_object', 'custom'),
(168, 54, '_menu_item_target', ''),
(169, 54, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(170, 54, '_menu_item_xfn', ''),
(171, 54, '_menu_item_url', 'http://localhost/wordpress'),
(177, 48, '_customize_restore_dismissed', '1'),
(178, 57, '_wp_trash_meta_status', 'publish'),
(179, 57, '_wp_trash_meta_time', '1644204574');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-02-07 00:55:53', '2022-02-07 00:55:53', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2022-02-07 01:43:31', '2022-02-07 01:43:31', '', 0, 'http://localhost/wordpress/?p=1', 0, 'post', '', 1),
(2, 1, '2022-02-07 00:55:53', '2022-02-07 00:55:53', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/wordpress/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2022-02-07 01:35:18', '2022-02-07 01:35:18', '', 0, 'http://localhost/wordpress/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-02-07 00:55:53', '2022-02-07 00:55:53', '<h2>Who we are</h2><p>Our website address is: http://localhost/wordpress.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-02-07 00:55:53', '2022-02-07 00:55:53', '', 0, 'http://localhost/wordpress/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-02-07 00:56:11', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-02-07 00:56:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=4', 0, 'post', '', 0),
(5, 1, '2022-02-07 00:59:55', '2022-02-07 00:59:55', '<div>\r\n<h6> News Updates</h6>\r\n<div>     Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n<div><a href=\"http://localhost/wordpress/news-update\" target=\"_blank\" rel=\"noopener\">news update</a></div>\r\n</div>', 'News Updates', '', 'publish', 'open', 'open', '', 'news-update', '', '', '2022-02-07 10:22:45', '2022-02-07 03:22:45', '', 0, 'http://localhost/wordpress/?p=5', 0, 'post', '', 0),
(6, 1, '2022-02-07 00:59:55', '2022-02-07 00:59:55', '', 'News Update', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2022-02-07 00:59:55', '2022-02-07 00:59:55', '', 5, 'http://localhost/wordpress/2022/02/07/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2022-02-07 01:00:12', '2022-02-07 01:00:12', '', 'Categories', '', 'trash', 'closed', 'closed', '', 'categories__trashed', '', '', '2022-02-07 09:25:28', '2022-02-07 02:25:28', '', 0, 'http://localhost/wordpress/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-02-07 01:00:12', '2022-02-07 01:00:12', '', 'Categories', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-02-07 01:00:12', '2022-02-07 01:00:12', '', 7, 'http://localhost/wordpress/2022/02/07/7-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2022-02-07 01:03:35', '0000-00-00 00:00:00', '', 'News', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-02-07 01:03:35', '2022-02-07 01:03:35', '', 0, 'http://localhost/wordpress/?page_id=10', 0, 'page', '', 0),
(11, 1, '2022-02-07 01:03:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-02-07 01:03:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?page_id=11', 0, 'page', '', 0),
(12, 1, '2022-02-07 01:06:31', '2022-02-07 01:06:31', '{\n    \"blogdescription\": {\n        \"value\": \"Situs web untuk informasi mengenai covid 19\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:06:31\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '6e1c5421-6381-431e-8151-bec42f494eb1', '', '', '2022-02-07 01:06:31', '2022-02-07 01:06:31', '', 0, 'http://localhost/wordpress/2022/02/07/6e1c5421-6381-431e-8151-bec42f494eb1/', 0, 'customize_changeset', '', 0),
(16, 1, '2022-02-07 01:10:33', '2022-02-07 01:10:33', '', 'News Updates', '', 'publish', 'closed', 'closed', '', 'news-update', '', '', '2022-02-07 10:14:06', '2022-02-07 03:14:06', '', 0, 'http://localhost/wordpress/?p=16', 3, 'nav_menu_item', '', 0),
(17, 1, '2022-02-07 01:11:30', '2022-02-07 01:11:30', '{\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [],\n            \"sidebar-1\": [\n                \"search-2\",\n                \"recent-posts-2\",\n                \"recent-comments-2\",\n                \"archives-2\",\n                \"categories-2\",\n                \"meta-2\"\n            ],\n            \"sidebar-2\": [],\n            \"sidebar-3\": []\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:11:30\"\n    },\n    \"twentysixteen::nav_menu_locations[primary]\": {\n        \"value\": 2,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:11:30\"\n    },\n    \"twentysixteen::nav_menu_locations[social]\": {\n        \"value\": 0,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:11:30\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8ec9d9ad-f71e-47c4-a850-f8a00dc545e7', '', '', '2022-02-07 01:11:30', '2022-02-07 01:11:30', '', 0, 'http://localhost/wordpress/2022/02/07/8ec9d9ad-f71e-47c4-a850-f8a00dc545e7/', 0, 'customize_changeset', '', 0),
(18, 1, '2022-02-07 01:12:57', '2022-02-07 01:12:57', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-02-07 10:14:05', '2022-02-07 03:14:05', '', 0, 'http://localhost/wordpress/?p=18', 1, 'nav_menu_item', '', 0),
(19, 1, '2022-02-07 01:20:02', '2022-02-07 01:20:02', '{\n    \"custom_css[twentysixteen]\": {\n        \"value\": \"\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:20:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c0121368-fda4-4feb-85e3-b63ecf556a59', '', '', '2022-02-07 01:20:02', '2022-02-07 01:20:02', '', 0, 'http://localhost/wordpress/2022/02/07/c0121368-fda4-4feb-85e3-b63ecf556a59/', 0, 'customize_changeset', '', 0),
(20, 1, '2022-02-07 01:20:03', '2022-02-07 01:20:03', '', 'twentysixteen', '', 'publish', 'closed', 'closed', '', 'twentysixteen', '', '', '2022-02-07 01:20:03', '2022-02-07 01:20:03', '', 0, 'http://localhost/wordpress/2022/02/07/twentysixteen/', 0, 'custom_css', '', 0),
(21, 1, '2022-02-07 01:20:03', '2022-02-07 01:20:03', '', 'twentysixteen', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2022-02-07 01:20:03', '2022-02-07 01:20:03', '', 20, 'http://localhost/wordpress/2022/02/07/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2022-02-07 01:21:49', '2022-02-07 01:21:49', '<div>Covid 19 Events Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n<div><a href=\"http://www.google.com\">telusuri lebih lanjut</a></div>\r\n&nbsp;', 'Covid 19 Events', '', 'publish', 'open', 'open', '', 'covid-19-events', '', '', '2022-02-07 10:19:30', '2022-02-07 03:19:30', '', 0, 'http://localhost/wordpress/?p=22', 0, 'post', '', 0),
(23, 1, '2022-02-07 01:21:49', '2022-02-07 01:21:49', 'lorem', 'Covid 19 events', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2022-02-07 01:21:49', '2022-02-07 01:21:49', '', 22, 'http://localhost/wordpress/2022/02/07/22-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2022-02-07 01:22:40', '2022-02-07 01:22:40', '', 'Covid 19 Events', '', 'publish', 'closed', 'closed', '', 'covid-19-events', '', '', '2022-02-07 10:14:06', '2022-02-07 03:14:06', '', 0, 'http://localhost/wordpress/?p=24', 4, 'nav_menu_item', '', 0),
(25, 1, '2022-02-07 01:31:29', '2022-02-07 01:31:29', '{\n    \"twentysixteen::page_background_color\": {\n        \"value\": \"#bbe9ea\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:31:29\"\n    },\n    \"twentysixteen::link_color\": {\n        \"value\": \"#000000\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:31:29\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b61ce245-056d-4437-bc78-26fd3d7c6a44', '', '', '2022-02-07 01:31:29', '2022-02-07 01:31:29', '', 0, 'http://localhost/wordpress/2022/02/07/b61ce245-056d-4437-bc78-26fd3d7c6a44/', 0, 'customize_changeset', '', 0),
(26, 1, '2022-02-07 01:32:15', '2022-02-07 01:32:15', '{\n    \"widget_categories[2]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjEwOiJDYXRlZ29yaWVzIjtzOjU6ImNvdW50IjtpOjE7czoxMjoiaGllcmFyY2hpY2FsIjtpOjA7czo4OiJkcm9wZG93biI7aTowO30=\",\n            \"title\": \"Categories\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"dd39c110642892ef4599059e740c4d07\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:32:15\"\n    },\n    \"sidebars_widgets[sidebar-1]\": {\n        \"value\": [\n            \"categories-2\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:32:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8d5518ec-d6e8-4539-8166-0f60572ca4a4', '', '', '2022-02-07 01:32:15', '2022-02-07 01:32:15', '', 0, 'http://localhost/wordpress/?p=26', 0, 'customize_changeset', '', 0),
(27, 1, '2022-02-07 01:33:50', '2022-02-07 01:33:50', '{\n    \"blogname\": {\n        \"value\": \"Copyright \\u00a9 2022 - All rights reserved\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:33:50\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'cbb7438d-6397-4178-a226-dc85de8aa1b0', '', '', '2022-02-07 01:33:50', '2022-02-07 01:33:50', '', 0, 'http://localhost/wordpress/?p=27', 0, 'customize_changeset', '', 0),
(28, 1, '2022-02-07 01:35:18', '2022-02-07 01:35:18', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/wordpress/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-02-07 01:35:18', '2022-02-07 01:35:18', '', 2, 'http://localhost/wordpress/2022/02/07/2-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2022-02-07 01:36:58', '2022-02-07 01:36:58', '{\n    \"blogname\": {\n        \"value\": \"COVID-19 NEWS\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:36:58\"\n    },\n    \"blogdescription\": {\n        \"value\": \"Situs web news covid 19\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:36:58\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '33f16b15-049a-4eba-98e1-dd254df355d4', '', '', '2022-02-07 01:36:58', '2022-02-07 01:36:58', '', 0, 'http://localhost/wordpress/2022/02/07/33f16b15-049a-4eba-98e1-dd254df355d4/', 0, 'customize_changeset', '', 0),
(30, 1, '2022-02-07 01:40:03', '2022-02-07 01:40:03', '{\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [],\n            \"sidebar-1\": [\n                \"categories-2\"\n            ],\n            \"sidebar-2\": [],\n            \"sidebar-3\": []\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:40:03\"\n    },\n    \"twentyfifteen::nav_menu_locations[primary]\": {\n        \"value\": 2,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:40:03\"\n    },\n    \"twentyfifteen::nav_menu_locations[social]\": {\n        \"value\": 0,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:40:03\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f63ae124-8587-4853-85df-2ffe97cdd033', '', '', '2022-02-07 01:40:03', '2022-02-07 01:40:03', '', 0, 'http://localhost/wordpress/2022/02/07/f63ae124-8587-4853-85df-2ffe97cdd033/', 0, 'customize_changeset', '', 0),
(31, 1, '2022-02-07 01:40:45', '2022-02-07 01:40:45', '{\n    \"widget_categories[2]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjEwOiJjYXRlZ29yaWVzIjtzOjU6ImNvdW50IjtpOjE7czoxMjoiaGllcmFyY2hpY2FsIjtpOjA7czo4OiJkcm9wZG93biI7aTowO30=\",\n            \"title\": \"categories\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"f4415c0aab052dac1f4a49d581c80112\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 01:40:31\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '785c68f7-c3ff-4b93-8113-9420f7cd0d6b', '', '', '2022-02-07 01:40:45', '2022-02-07 01:40:45', '', 0, 'http://localhost/wordpress/?p=31', 0, 'customize_changeset', '', 0),
(32, 1, '2022-02-07 01:43:31', '2022-02-07 01:43:31', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-02-07 01:43:31', '2022-02-07 01:43:31', '', 1, 'http://localhost/wordpress/2022/02/07/1-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2022-02-07 01:44:41', '2022-02-07 01:44:41', 'facebook <a href=\"http://www.facebok.com\">http://www.facebok.com</a>', 'social media', '', 'trash', 'open', 'open', '', 'social-media__trashed', '', '', '2022-02-07 01:45:25', '2022-02-07 01:45:25', '', 0, 'http://localhost/wordpress/?p=33', 0, 'post', '', 0),
(34, 1, '2022-02-07 01:44:41', '2022-02-07 01:44:41', 'facebook <a href=\"http://www.facebok.com\">http://www.facebok.com</a>', 'social media', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2022-02-07 01:44:41', '2022-02-07 01:44:41', '', 33, 'http://localhost/wordpress/2022/02/07/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2022-02-07 08:58:15', '2022-02-07 01:58:15', '<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n</div>', 'News Updates', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2022-02-07 08:58:15', '2022-02-07 01:58:15', '', 5, 'http://localhost/wordpress/2022/02/07/5-revision-v1/', 0, 'revision', '', 0),
(36, 1, '2022-02-07 08:58:51', '2022-02-07 01:58:51', '<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n</div>', 'Covid 19 events', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2022-02-07 08:58:51', '2022-02-07 01:58:51', '', 22, 'http://localhost/wordpress/2022/02/07/22-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2022-02-07 09:00:39', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-02-07 09:00:39', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?page_id=37', 0, 'page', '', 0),
(39, 1, '2022-02-07 09:01:37', '2022-02-07 02:01:37', 'http://localhost/wordpress/wp-content/uploads/2022/02/seo-by-rank-math.1.0.24.zip', 'seo-by-rank-math.1.0.24.zip', '', 'private', 'open', 'closed', '', 'seo-by-rank-math-1-0-24-zip', '', '', '2022-02-07 09:01:37', '2022-02-07 02:01:37', '', 0, 'http://localhost/wordpress/wp-content/uploads/2022/02/seo-by-rank-math.1.0.24.zip', 0, 'attachment', '', 0),
(43, 1, '2022-02-07 09:13:50', '2022-02-07 02:13:50', 'http://localhost/wordpress/wp-content/uploads/2022/02/blankslate.2022-1.zip', 'blankslate.2022.zip', '', 'private', 'open', 'closed', '', 'blankslate-2022-zip-2', '', '', '2022-02-07 09:13:50', '2022-02-07 02:13:50', '', 0, 'http://localhost/wordpress/wp-content/uploads/2022/02/blankslate.2022-1.zip', 0, 'attachment', '', 0),
(44, 2, '2022-02-07 09:15:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-02-07 09:15:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=44', 0, 'post', '', 0),
(45, 2, '2022-02-07 09:17:19', '2022-02-07 02:17:19', '', '', '', 'publish', 'closed', 'closed', '', 'localhost-wordpress', '', '', '2022-02-07 09:17:19', '2022-02-07 02:17:19', '', 0, 'http://localhost/wordpress/?post_type=vslides&#038;p=45', 0, 'vslides', '', 0),
(46, 1, '2022-02-07 09:43:49', '2022-02-07 02:43:49', '{\n    \"twentyfifteen::sidebar_textcolor\": {\n        \"value\": \"#ffffff\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 02:43:11\"\n    },\n    \"twentyfifteen::header_background_color\": {\n        \"value\": \"#32c1a9\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 02:43:11\"\n    },\n    \"twentyfifteen::background_color\": {\n        \"value\": \"#056662\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 02:43:49\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b2e2d44f-c17e-4fda-9a65-d2a73b9cb9e9', '', '', '2022-02-07 09:43:49', '2022-02-07 02:43:49', '', 0, 'http://localhost/wordpress/?p=46', 0, 'customize_changeset', '', 0),
(47, 1, '2022-02-07 09:51:28', '0000-00-00 00:00:00', '{\n    \"custom_css[twentyfifteen]\": {\n        \"value\": \".post{\\n\\tbackground-color:#eee  !important;\\n\\tcolor:black !important;\\n\\tmargin-top:2em;\\n}\\n.post .entry-title{\\n\\ttext-align:center;\\n}\\n\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 02:51:28\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', 'b58c44ab-236f-4b9a-b616-31a4b0b4a303', '', '', '2022-02-07 09:51:28', '2022-02-07 02:51:28', '', 0, 'http://localhost/wordpress/?p=47', 0, 'customize_changeset', '', 0),
(48, 1, '2022-02-07 09:53:46', '0000-00-00 00:00:00', '{\n    \"custom_css[twentyfifteen]\": {\n        \"value\": \".post{\\n\\tmargin-top:5em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 02:53:46\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', 'edd9a8cc-d57c-475d-82fa-8dd8bfe8f347', '', '', '2022-02-07 09:53:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/?p=48', 0, 'customize_changeset', '', 0),
(50, 1, '2022-02-07 10:18:27', '2022-02-07 03:18:27', '<div>Covid 19 Events Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\n<div><a href=\"http://www.google.com\">telusuri</a></div>', 'Covid 19 Events', '', 'inherit', 'closed', 'closed', '', '22-autosave-v1', '', '', '2022-02-07 10:18:27', '2022-02-07 03:18:27', '', 22, 'http://localhost/wordpress/2022/02/07/22-autosave-v1/', 0, 'revision', '', 0),
(51, 1, '2022-02-07 10:05:24', '2022-02-07 03:05:24', '<h1>covid 19 events</h1>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>', 'Covid 19 events', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2022-02-07 10:05:24', '2022-02-07 03:05:24', '', 22, 'http://localhost/wordpress/2022/02/07/22-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2022-02-07 10:22:16', '2022-02-07 03:22:16', '<div>\n<h6> News Updates</h6>\n<div>     Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\n<div><a href=\"http://localhost/wordpress/news-update\" target=\"_blank\" rel=\"noopener\">news update</a></div>\n</div>', 'News Updates', '', 'inherit', 'closed', 'closed', '', '5-autosave-v1', '', '', '2022-02-07 10:22:16', '2022-02-07 03:22:16', '', 5, 'http://localhost/wordpress/2022/02/07/5-autosave-v1/', 0, 'revision', '', 0),
(53, 1, '2022-02-07 10:09:24', '2022-02-07 03:09:24', '<div>\r\n<div>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n<div><a href=\"http://localhost/wordpress/news-update\" target=\"_blank\" rel=\"noopener\">news update</a></div>\r\n</div>', 'News Updates', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2022-02-07 10:09:24', '2022-02-07 03:09:24', '', 5, 'http://localhost/wordpress/2022/02/07/5-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2022-02-07 10:14:05', '2022-02-07 03:14:05', '', 'Our Category', '', 'publish', 'closed', 'closed', '', 'our-category', '', '', '2022-02-07 10:14:05', '2022-02-07 03:14:05', '', 0, 'http://localhost/wordpress/?p=54', 2, 'nav_menu_item', '', 0),
(55, 1, '2022-02-07 10:19:30', '2022-02-07 03:19:30', '<div>Covid 19 Events Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n<div><a href=\"http://www.google.com\">telusuri lebih lanjut</a></div>\r\n&nbsp;', 'Covid 19 Events', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2022-02-07 10:19:30', '2022-02-07 03:19:30', '', 22, 'http://localhost/wordpress/2022/02/07/22-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2022-02-07 10:22:45', '2022-02-07 03:22:45', '<div>\r\n<h6> News Updates</h6>\r\n<div>     Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias, odio ad laboriosam non veritatis a fuga. Magnam quod qui ipsa explicabo temporibus fuga eum ut cupiditate, quo, dolorem sunt perferendis sequi dolore veritatis reprehenderit eveniet. Dolores at rem reprehenderit, voluptatem aliquid id. Facere repellendus sed recusandae optio voluptatibus voluptate animi minima soluta officiis voluptates fugit nihil accusamus, modi temporibus, deserunt quam nobis incidunt esse tempora rerum! Consectetur culpa ipsam delectus quia repellendus molestias maiores, iure quasi ducimus minus eum expedita, nostrum accusantium, eius aspernatur aperiam vitae nemo totam? Voluptatibus itaque doloremque eaque praesentium sapiente labore consectetur neque saepe dolore officia!</div>\r\n<div><a href=\"http://localhost/wordpress/news-update\" target=\"_blank\" rel=\"noopener\">news update</a></div>\r\n</div>', 'News Updates', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2022-02-07 10:22:45', '2022-02-07 03:22:45', '', 5, 'http://localhost/wordpress/2022/02/07/5-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2022-02-07 10:29:34', '2022-02-07 03:29:34', '{\n    \"widget_custom_html[2]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YToyOntzOjU6InRpdGxlIjtzOjEyOiJGb2xsb3cgVXMgT24iO3M6NzoiY29udGVudCI7czoxMTE6IjxwPg0KCTxhIGhyZWY9Ind3dy5mYWNlYm9vay5jb20iPmZhY2Vib29rPC9hPg0KPC9wPg0KPHA+DQoJPGE+SW5zdGFncmFtPC9hPg0KPC9wPg0KPHA+DQoJPGE+dHdpdHRlcjwvYT4NCjwvcD4NCiI7fQ==\",\n            \"title\": \"Follow Us On\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"a792fc664b33bb4956cb9d95bbdc5651\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2022-02-07 03:29:34\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f9190211-2d62-40da-8d8e-7d00e6f37184', '', '', '2022-02-07 10:29:34', '2022-02-07 03:29:34', '', 0, 'http://localhost/wordpress/2022/02/07/f9190211-2d62-40da-8d8e-7d00e6f37184/', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rank_math_404_logs`
--

CREATE TABLE `wp_rank_math_404_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uri` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `times_accessed` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `referer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_rank_math_404_logs`
--

INSERT INTO `wp_rank_math_404_logs` (`id`, `uri`, `accessed`, `times_accessed`, `ip`, `referer`, `user_agent`) VALUES
(1, 'wraf', '2022-02-07 10:37:54', 2, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rank_math_internal_links`
--

CREATE TABLE `wp_rank_math_internal_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `target_post_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rank_math_internal_meta`
--

CREATE TABLE `wp_rank_math_internal_meta` (
  `object_id` bigint(20) UNSIGNED NOT NULL,
  `internal_link_count` int(10) UNSIGNED DEFAULT 0,
  `external_link_count` int(10) UNSIGNED DEFAULT 0,
  `incoming_link_count` int(10) UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rank_math_redirections`
--

CREATE TABLE `wp_rank_math_redirections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sources` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_to` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_code` smallint(4) UNSIGNED NOT NULL,
  `hits` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_accessed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rank_math_redirections_cache`
--

CREATE TABLE `wp_rank_math_redirections_cache` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirection_id` bigint(20) UNSIGNED NOT NULL,
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `object_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `is_redirected` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rank_math_sc_analytics`
--

CREATE TABLE `wp_rank_math_sc_analytics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `property` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` mediumint(6) NOT NULL,
  `impressions` mediumint(6) NOT NULL,
  `position` double NOT NULL,
  `ctr` double NOT NULL,
  `dimension` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Our Categories', 'our-categories', 0),
(2, 'Home', 'home', 0),
(3, 'News Updates', 'news-updates', 0),
(5, 'Each selected editor', 'each-selected-editor', 0),
(7, 'COVID-19 Events', 'covid-19-events-news', 0),
(8, 'news update', 'news-update', 0),
(9, 'update news', 'update-news', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 1, 0),
(5, 8, 0),
(5, 9, 0),
(16, 2, 0),
(18, 2, 0),
(22, 1, 0),
(24, 2, 0),
(33, 1, 0),
(54, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 4),
(3, 3, 'category', 'halaman update info tentang covid', 0, 0),
(5, 5, 'category', '', 1, 0),
(7, 7, 'category', 'halaman events covid 19', 1, 0),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin20'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,theme_editor_notice,bws_shortcode_button_tooltip'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 2, 'nickname', '20editor'),
(19, 2, 'first_name', 'editor'),
(20, 2, 'last_name', 'editor'),
(21, 2, 'description', ''),
(22, 2, 'rich_editing', 'true'),
(23, 2, 'syntax_highlighting', 'true'),
(24, 2, 'comment_shortcuts', 'false'),
(25, 2, 'admin_color', 'fresh'),
(26, 2, 'use_ssl', '0'),
(27, 2, 'show_admin_bar_front', 'true'),
(28, 2, 'locale', ''),
(29, 2, 'wp_capabilities', 'a:1:{s:6:\"editor\";b:1;}'),
(30, 2, 'wp_user_level', '7'),
(31, 2, 'dismissed_wp_pointers', 'wp496_privacy,bws_shortcode_button_tooltip'),
(32, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}'),
(33, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}'),
(34, 1, 'nav_menu_recently_edited', '2'),
(35, 1, 'wp_user-settings', 'editor=tinymce&mfold=o&post_dfw=off'),
(36, 1, 'wp_user-settings-time', '1644201680'),
(37, 1, 'manageedit-postcolumnshidden', 'a:3:{i:0;s:0:\"\";i:1;s:15:\"rank_math_title\";i:2;s:21:\"rank_math_description\";}'),
(38, 1, 'manageedit-postcolumnshidden_default', '1'),
(39, 1, 'manageedit-pagecolumnshidden', 'a:3:{i:0;s:0:\"\";i:1;s:15:\"rank_math_title\";i:2;s:21:\"rank_math_description\";}'),
(40, 1, 'manageedit-pagecolumnshidden_default', '1'),
(41, 1, 'manageedit-vslidescolumnshidden', 'a:3:{i:0;s:0:\"\";i:1;s:15:\"rank_math_title\";i:2;s:21:\"rank_math_description\";}'),
(42, 1, 'manageedit-vslidescolumnshidden_default', '1'),
(43, 1, 'session_tokens', 'a:4:{s:64:\"0c7b72be2cbf44c7b7f5acd79b9d9611fbcf3cf475f7a1a1041bcb33d0007345\";a:4:{s:10:\"expiration\";i:1644372601;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.81 Safari/537.36\";s:5:\"login\";i:1644199801;}s:64:\"d5b2eb44620a1274717e024994463903175d7411f530f4b421f5b77bb71c3532\";a:4:{s:10:\"expiration\";i:1644373113;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.81 Safari/537.36\";s:5:\"login\";i:1644200313;}s:64:\"5c1d3f0aa306b05016794d813d72a389723f89bb46f6e3610fe6989350932923\";a:4:{s:10:\"expiration\";i:1644374257;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.81 Safari/537.36\";s:5:\"login\";i:1644201457;}s:64:\"95087f6f9d442af211ac343ac357b59820ff60fd06ebe21b2ee85ced1ace355e\";a:4:{s:10:\"expiration\";i:1644375471;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.81 Safari/537.36\";s:5:\"login\";i:1644202671;}}'),
(45, 2, 'wp_dashboard_quick_press_last_post_id', '44'),
(46, 1, 'closedpostboxes_post', 'a:1:{i:0;s:9:\"formatdiv\";}'),
(47, 1, 'metaboxhidden_post', 'a:8:{i:0;s:12:\"revisionsdiv\";i:1;s:11:\"postexcerpt\";i:2;s:13:\"trackbacksdiv\";i:3;s:10:\"postcustom\";i:4;s:16:\"commentstatusdiv\";i:5;s:11:\"commentsdiv\";i:6;s:7:\"slugdiv\";i:7;s:9:\"authordiv\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin20', '$P$BX8.zI6PZplNur5FHHmrEq4lbcW0J0.', 'admin20', 'admin20@gmail.com', '', '2022-02-07 00:55:52', '', 0, 'admin20'),
(2, '20editor', '$P$BqciQS56f0TgOOx//7chLv3V4N7eEz0', '20editor', 'editor20@gmail.com', '', '2022-02-07 00:57:40', '', 0, 'editor editor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_aiowps_events`
--
ALTER TABLE `wp_aiowps_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_aiowps_failed_logins`
--
ALTER TABLE `wp_aiowps_failed_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_aiowps_global_meta`
--
ALTER TABLE `wp_aiowps_global_meta`
  ADD PRIMARY KEY (`meta_id`);

--
-- Indexes for table `wp_aiowps_login_activity`
--
ALTER TABLE `wp_aiowps_login_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_aiowps_login_lockdown`
--
ALTER TABLE `wp_aiowps_login_lockdown`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_aiowps_permanent_block`
--
ALTER TABLE `wp_aiowps_permanent_block`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_cntctfrm_field`
--
ALTER TABLE `wp_cntctfrm_field`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_rank_math_404_logs`
--
ALTER TABLE `wp_rank_math_404_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uri` (`uri`(191));

--
-- Indexes for table `wp_rank_math_internal_links`
--
ALTER TABLE `wp_rank_math_internal_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `link_direction` (`post_id`,`type`);

--
-- Indexes for table `wp_rank_math_internal_meta`
--
ALTER TABLE `wp_rank_math_internal_meta`
  ADD UNIQUE KEY `object_id` (`object_id`);

--
-- Indexes for table `wp_rank_math_redirections`
--
ALTER TABLE `wp_rank_math_redirections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `wp_rank_math_redirections_cache`
--
ALTER TABLE `wp_rank_math_redirections_cache`
  ADD PRIMARY KEY (`id`),
  ADD KEY `redirection_id` (`redirection_id`);

--
-- Indexes for table `wp_rank_math_sc_analytics`
--
ALTER TABLE `wp_rank_math_sc_analytics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `property` (`property`(191));

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_aiowps_events`
--
ALTER TABLE `wp_aiowps_events`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_aiowps_failed_logins`
--
ALTER TABLE `wp_aiowps_failed_logins`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_aiowps_global_meta`
--
ALTER TABLE `wp_aiowps_global_meta`
  MODIFY `meta_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_aiowps_login_activity`
--
ALTER TABLE `wp_aiowps_login_activity`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_aiowps_login_lockdown`
--
ALTER TABLE `wp_aiowps_login_lockdown`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_aiowps_permanent_block`
--
ALTER TABLE `wp_aiowps_permanent_block`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_cntctfrm_field`
--
ALTER TABLE `wp_cntctfrm_field`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=310;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `wp_rank_math_404_logs`
--
ALTER TABLE `wp_rank_math_404_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_rank_math_internal_links`
--
ALTER TABLE `wp_rank_math_internal_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rank_math_redirections`
--
ALTER TABLE `wp_rank_math_redirections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rank_math_redirections_cache`
--
ALTER TABLE `wp_rank_math_redirections_cache`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rank_math_sc_analytics`
--
ALTER TABLE `wp_rank_math_sc_analytics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
